import os

class Corpus:
    def __init__(self):
        pass

    def combine_summaries(self, nonseparated_summary_folder, speaker_summary_folder, listener_summary_folder):
        filelist_nonseparated = sorted(os.listdir(nonseparated_summary_folder))
        filelist_speaker = sorted(os.listdir(speaker_summary_folder))
        filelist_listener = sorted(os.listdir(listener_summary_folder))
        filelist_nonseparated = [f for f in filelist_nonseparated if f.endswith(".txt")]
        filelist_speaker = [f for f in filelist_speaker if f.endswith(".txt")]
        filelist_listener = [f for f in filelist_listener if f.endswith(".txt")]
        all_summaries_nonseparated = ''
        all_summaries_speaker = ''
        all_summaries_listener = ''

        for filename in filelist_nonseparated:
            nonseparated_file = open(f'{nonseparated_summary_folder}{filename}','r')
            all_text1 = nonseparated_file.read()
            print('all_text1 :', all_text1)
            all_summaries_nonseparated += all_text1 + '.' + '\n'
            nonseparated_file.close()
        for filename in filelist_speaker:
            speaker_file = open(f'{speaker_summary_folder}{filename}','r')
            all_text2 = speaker_file.read()
            print('all_text2 :', all_text2)
            all_summaries_speaker += all_text2 + '.' + '\n'
            speaker_file.close()
        for filename in filelist_listener:
            listener_file = open(f'{listener_summary_folder}{filename}','r')
            all_text3 = listener_file.read()
            print('all_text3 :', all_text3)
            all_summaries_listener += all_text3 + '.' + '\n'
            listener_file.close()
        return all_summaries_nonseparated, all_summaries_speaker, all_summaries_listener


def main():
    CorpusFolder = '/home/gokmenm/hma_data/data_out/corpus/'
    nonseparated_summary_folder = '/home/gokmenm/hma_data/data_out/letter_summaries/nonseparated/'
    speaker_summary_folder = '/home/gokmenm/hma_data/data_out/letter_summaries/speaker/'
    listener_summary_folder = '/home/gokmenm/hma_data/data_out/letter_summaries/listener/'
    if not os.path.exists(CorpusFolder):
        os.makedirs(CorpusFolder)
    corpus = Corpus()
    all_summaries_nonseparated, all_summaries_speaker, all_summaries_listener = corpus.combine_summaries(nonseparated_summary_folder, speaker_summary_folder, listener_summary_folder)
    file1 = open(f"{CorpusFolder}all_summaries_nonseparated.txt", "w")
    for line in all_summaries_nonseparated:
        file1.write(line)
    file1.close()
    file2 = open(f"{CorpusFolder}all_summaries_speaker.txt", 'w')
    for line in all_summaries_speaker:
        file2.write(line)
    file2.close()
    file3 = open(f"{CorpusFolder}all_summaries_listener.txt", 'w')
    for line in all_summaries_listener:
        file3.write(line)
    file3.close()


if __name__ == '__main__':
    main()