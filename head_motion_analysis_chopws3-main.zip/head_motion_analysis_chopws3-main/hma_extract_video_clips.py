import cv2
import pandas as pd
import os

class ExtractVideoClips:
    def __init__(self):
        pass

    def process_segment(self, row, input_folder, output_folder):
        # drop _angles.cvs part from the file name *_angles.csv
        filename = row['filename'].replace('_angles.csv', '.mp4')
        print(filename)
        video_path = os.path.join(input_folder, filename)

        output_label_folder = os.path.join(output_folder, str(row['gmm_cluster_name']))

        if not os.path.exists(output_label_folder):
            os.makedirs(output_label_folder)

        output_video_filename = f"{output_label_folder}/{filename}_segment_{row['segment_id']}.mp4"
        extract_frames(video_path, row['first_frame'], row['last_frame'], output_video_filename)

        delete_png_files(output_label_folder)
    def extract_frames(self, video_file, first_frame, last_frame, output_video_filename):
        # Open the video file
        cap = cv2.VideoCapture(video_file)

        # Get video properties
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        # Check if the provided frame numbers are within the video range
        if first_frame < 0:
            first_frame = 0
        if last_frame >= total_frames:
            last_frame = total_frames - 1

        if first_frame < 0 or last_frame >= total_frames or first_frame > last_frame:
            print("Invalid frame numbers provided.")
            print(f"first frames: {first_frame}", f" last frame: {last_frame}", f", Total frames: {total_frames}")
            return

        # Set the start and end positions
        cap.set(cv2.CAP_PROP_POS_FRAMES, first_frame)
        start_frame = first_frame
        end_frame = last_frame

        # Create a VideoWriter object to save the clipped video
        output_file_no_extension = os.path.splitext(output_video_filename)[0]
        output_file = f"{output_file_no_extension}_{round((first_frame + last_frame) / 2)}_range_{first_frame}_{last_frame}.mp4"
        #output_file = f"clipped_{first_frame}_{last_frame}.mp4"
        codec = cv2.VideoWriter_fourcc(*'mp4v')
        output_fps = fps
        output_size = (int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))
        out = cv2.VideoWriter(output_file, codec, output_fps, output_size)

        # Read and write frames between the specified range
        while start_frame <= end_frame:
            ret, frame = cap.read()
            if ret:
                out.write(frame)
            start_frame += 1

        # Release the video objects
        cap.release()
        out.release()
        cv2.destroyAllWindows()

        print(f"Clipped video saved as {output_file}")
        #delete *.png files in the output folder
        #delete_png_files(output_label_folder)

    def delete_png_files(self,folder_path):
        try:
            # List all files in the specified folder
            files = os.listdir(folder_path)

            # Iterate through the files and delete *.png files
            for file in files:
                if file.endswith(".png"):
                    file_path = os.path.join(folder_path, file)
                    os.remove(file_path)
                    #print(f"Deleted: {file_path}")

            print("Deletion of png files completed.")

        except Exception as e:
            print(f"An error occurred: {e}")


    def process_csv(self,csv_path, input_folder, output_folder):
        df = pd.read_csv(csv_path)

        for index, row in df.iterrows():
            process_segment(row, input_folder, output_folder)

    def create_video_mosaic(self,subfolder_path, output_path):
        try:
            # Get a list of all *.mp4 files in the subfolder
            mp4_files = [file for file in os.listdir(subfolder_path) if file.endswith('.mp4')]

            if not mp4_files:
                print(f"No *.mp4 files found in {subfolder_path}")
                return

            # Initialize an empty list to store video objects
            videos = []

            # Read each video and store in the videos list
            for mp4_file in mp4_files:
                video_path = os.path.join(subfolder_path, mp4_file)
                video = cv2.VideoCapture(video_path)
                videos.append(video)

            # Get video dimensions
            width = int(videos[0].get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(videos[0].get(cv2.CAP_PROP_FRAME_HEIGHT))

            # Calculate the number of rows and columns in the mosaic
            rows = len(videos) // 2 + (len(videos) % 2 > 0)  # Ensure at least one row
            cols = min(len(videos), 2)

            # Create an output video file
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            output_video = cv2.VideoWriter(output_path, fourcc, 20.0, (width * cols, height * rows))

            while True:
                frames = []
                for video in videos:
                    ret, frame = video.read()
                    if not ret:
                        # Restart the video when it reaches the end
                        video.set(cv2.CAP_PROP_POS_FRAMES, 0)
                        ret, frame = video.read()

                    frames.append(frame)

                # Create mosaic layout with 4 videos per row
                mosaic_frames = []
                for i in range(0, len(frames), cols):
                    row_frames = frames[i:i + cols]
                    row_mosaic = cv2.hconcat(row_frames)
                    mosaic_frames.append(row_mosaic)
                mosaic_frame = cv2.vconcat(mosaic_frames)
                output_video.write(mosaic_frame)

                cv2.imshow('Video Mosaic', mosaic_frame)
                # Break the loop if 'Q' key is pressed
                if cv2.waitKey(30) & 0xFF == ord('Q'):
                    break

            # Release resources
            output_video.release()
            cv2.destroyAllWindows()

        except Exception as e:
            print(f"An error occurred: {e}")
        print("end of create_video_mosaic")

    def create_video_mosaic_resized(self,subfolder_path, output_path, target_width = 240, target_height = 140):
        try:
            # Get a list of all *.mp4 files in the subfolder
            mp4_files = [file for file in os.listdir(subfolder_path) if file.endswith('.mp4')]

            if not mp4_files:
                print(f"No *.mp4 files found in {subfolder_path}")
                return

            # Initialize an empty list to store video objects and resized frames
            videos = []
            resized_frames = []

            # Read each video and store resized frames in the lists
            for mp4_file in mp4_files:
                video_path = os.path.join(subfolder_path, mp4_file)
                video = cv2.VideoCapture(video_path)
                videos.append(video)

                ret, frame = video.read()
                if ret:
                    resized_frame = resize_frame(frame, target_width, target_height)
                    resized_frames.append(resized_frame)

            # Get the resized frame dimensions
            width = target_width
            height = target_height

            # Calculate the number of rows and columns in the mosaic
            rows = len(resized_frames) // 5 + (len(resized_frames) % 5 > 0)  # Ensure at least one row
            cols = min(len(resized_frames), 5)

            # Create an output video file
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            output_video = cv2.VideoWriter(output_path, fourcc, 20.0, (width * cols, height * rows))

            while True:
                frames = []
                for resized_frame in resized_frames:
                    frames.append(resized_frame)

                # Create mosaic layout with 4 videos per row
                mosaic_frames = []
                for i in range(0, len(frames), cols):
                    row_frames = frames[i:i + cols]
                    row_mosaic = cv2.hconcat(row_frames)
                    mosaic_frames.append(row_mosaic)

                mosaic_frame = cv2.vconcat(mosaic_frames)
                output_video.write(mosaic_frame)

                cv2.imshow('Video Mosaic', mosaic_frame)

                # Break the loop if 'Q' key is pressed
                if cv2.waitKey(30) & 0xFF == ord('Q'):
                    break

            # Release resources
            output_video.release()
            cv2.destroyAllWindows()

        except Exception as e:
            print(f"An error occurred: {e}")


    def resize_frame(self,frame, target_width, target_height):
        return cv2.resize(frame, (target_width, target_height))
    def mosaic_videos(self,root_folder_path):
        # Iterate through subfolders and create mosaic videos
        for subfolder in sorted(os.listdir(root_folder_path)):
            subfolder_path = os.path.join(root_folder_path, subfolder)
            if os.path.isdir(subfolder_path):
                output_folder = f"{root_folder_path}/{subfolder}/mosaic"
                output_path = f"{root_folder_path}/{subfolder}/mosaic/{subfolder}_mosaic.mp4"
                print(f"Creating mosaic video as {output_path} ...")
                #create folder if it does not exist
                if not os.path.exists(output_folder):
                    print('creating mosaic folder', output_folder)
                    os.makedirs(output_folder)
                create_video_mosaic_resized(subfolder_path, output_path, 240, 140)


if __name__ == "__main__":
    main()
def main():
    csv_file_path = '/Users/muhittingokmen/Dropbox/CHOP-MEF-codes/Kinemes/data_in/all_segments_clustered_sampled_derivatives/segments_from_all_files_with_cluster_info.csv'

    RootDir = '/Users/muhittingokmen/Dropbox/CHOP-MEF-data_in/monodic'
    videoFolder = f"{RootDir}/videos/"
    OutputFolder = f"{RootDir}/kineme_video_clips/"

    input_videos_folder = videoFolder
    output_folder = OutputFolder

    process_csv(csv_file_path, input_videos_folder, output_folder)
    # Generate mosaic videos of each sub folder in the output folder
    # Specify the root folder path containing subfolders with *.mp4 files
    root_folder_path = output_folder
    mosaic_videos(root_folder_path)

    csv_file_path = '/Users/muhittingokmen/Dropbox/CHOP-MEF-codes/Kinemes/data_in/all_segments_clustered_sampled_angles/segments_from_all_files_with_cluster_info.csv'
    input_videos_folder = '/Users/muhittingokmen/Dropbox/CHOP-MEF-codes/Dense-Head-Pose-Estimation/video_dir'
    output_folder = '/Users/muhittingokmen/Dropbox/CHOP-MEF-codes/Kinemes/data_in/all_segments_clustered_sampled_angles/clipped_videos_sampled_angles'
    process_csv(csv_file_path, input_videos_folder, output_folder)
    # Generate mosaic videos of each sub folder in the output folder
    # Specify the root folder path containing subfolders with *.mp4 files
    root_folder_path = output_folder
    mosaic_videos(root_folder_path)


