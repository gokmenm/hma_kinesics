import sys, time, os, argparse, subprocess, glob, pdb
# this program reads the video files in the video_dir
# and extracts the video frames by using the code video_to_angles.py and head motion angles, yaw, pitch, roll
# and saves them in the [../video_dir]/angles directory
# The angles are saved in a csv file with the same name as the video file
# but with the extension .csv
# import show_peaks_valleys  as spv
import argparse, os
import service
import cv2
import pandas as pd
class AugmentVideo():
    def __init__(self):
        self.keypoint = self.KeyPoint1D()
        pass

    class KeyPoint1D:
        def __init__(self):
            self.pt = None
            self.level = None
            self.size = None
            self.response = None
            self.class_id = None
            self.type = None
            self.angle = None
            self.first_frame = None
            self.last_frame = None

    def augment_video(self, video_filename, keypoints_yaw, keypoints_pitch, keypoints_roll, speaker_filename, output_video_filename , mode="pose", color=(224, 255, 255)):

        #keypoints_yaw = pd.read_csv(keypoints_yaw)
        #keypoints_pitch = pd.read_csv(keypoints_pitch)
        #keypoints_roll = pd.read_csv(keypoints_roll)

        speaker_labels = pd.read_csv(speaker_filename)
        speaking = speaker_labels['speaking'].copy()

        #print("speech_labels: ", speech_labels['speaking'][0:10])
        fd = service.UltraLightFaceDetecion("weights/RFB-320.tflite",
                                            conf_threshold=0.95)
        if mode in ["sparse", "pose"]:
            fa = service.DepthFacialLandmarks("weights/sparse_face.tflite")
        else:
            fa = service.DenseFaceReconstruction("weights/dense_face.tflite")
            if args.mode == "mesh":
                color = service.TrianglesMeshRender("asset/render.so",
                                                    "asset/triangles.npy")
        handler = getattr(service, mode)
        cap = cv2.VideoCapture(video_filename)
        fps = cap.get(cv2.CAP_PROP_FPS)
        no_of_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        print("frame_width:", frame_width, "frame_height:", frame_height, "fps:", fps, "no_of_frames:", no_of_frames)

        key_level_yaw = [0] * (no_of_frames)
        key_level_pitch = [0] * (no_of_frames)
        key_level_roll = [0] * (no_of_frames)
        key_response_yaw = [0] * (no_of_frames)
        key_response_pitch = [0] * (no_of_frames)
        key_response_roll = [0] * (no_of_frames)

        print("length of speech_labels: ", len(speaker_labels['speaking']))
        print("length of video         : ", no_of_frames)
        for idk in range(len(keypoints_yaw)):
            if keypoints_yaw[idk].pt > 0.0:
                first_frame = max(int(keypoints_yaw[idk].first_frame), 0)
                last_frame = min(int(keypoints_yaw[idk].last_frame),no_of_frames-1)
                for i in range(first_frame , last_frame + 1):
                    key_level_yaw[i] = keypoints_yaw[idk].octave
                    key_response_yaw[i] = keypoints_yaw[idk].response
        for idk in range(len(keypoints_pitch)):
            if keypoints_pitch[idk].pt > 0.0:
                first_frame = max(int(keypoints_pitch[idk].first_frame), 0)
                last_frame = min(int(keypoints_pitch[idk].last_frame), no_of_frames - 1)
                for i in range(first_frame, last_frame + 1):
                    key_level_pitch[i] = keypoints_pitch[idk].octave
                    key_response_pitch[i] = keypoints_pitch[idk].response
        for idk in range(len(keypoints_roll)):
            if keypoints_roll[idk].pt > 0.0:
                first_frame = max(int(keypoints_roll[idk].first_frame), 0)
                last_frame = min(int(keypoints_roll[idk].last_frame), no_of_frames - 1)
                for i in range(first_frame, last_frame + 1):
                    key_level_roll[i] = keypoints_roll[idk].octave
                    key_response_roll[i] = keypoints_roll[idk].response

        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_video_filename, fourcc, fps, (frame_width, frame_height))
        print("saving video to : ", output_video_filename)
        frame_no = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            # face detection
            boxes, scores = fd.inference(frame)
            # raw copy for reconstruction
            feed = frame.copy()
            for results in fa.get_landmarks(feed, boxes):
                #print("landmarks :", results)
                handler(frame, results, color)

            cv2.putText(frame, f"frame: {frame_no}", (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 1, cv2.LINE_AA)
            cv2.putText(frame, f"yaw_level:: {key_level_yaw[frame_no]}", (30, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255),
                        1, cv2.LINE_AA)
            cv2.putText(frame, f"yaw_response:: {key_response_yaw[frame_no]}", (30, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.75,
                        (0, 0, 255),1, cv2.LINE_AA)
            cv2.putText(frame, f"pitch_level:: {key_level_pitch[frame_no]}", (30, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.75,
                        (0, 0, 255),1, cv2.LINE_AA)
            cv2.putText(frame, f"pitch_response:: {key_response_pitch[frame_no]}", (30, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.75,
                        (0, 0, 255), 1, cv2.LINE_AA)
            cv2.putText(frame, f"roll_level:: {key_level_roll[frame_no]}", (30, 130), cv2.FONT_HERSHEY_SIMPLEX, 0.75,
                        (0, 0, 255),1, cv2.LINE_AA)
            cv2.putText(frame, f"roll_response:: {key_response_roll[frame_no]}", (30, 150), cv2.FONT_HERSHEY_SIMPLEX, 0.75,
                        (0, 0, 255), 1, cv2.LINE_AA)

            if key_response_yaw[frame_no] > 0 :   #PEAK
                label1 = "LEFT + "
                cv2.putText(frame, label1, (150, 300), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 255), 2, cv2.LINE_AA)
            elif key_response_yaw[frame_no] < 0 :   #VALLEY
                label1 = "RIGHT +  "
                cv2.putText(frame, label1, (800, 300), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 255), 4, cv2.LINE_AA)
            else:
                label1 = ""
                #cv2.putText(frame, label1, (450, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 0, 0), 2, cv2.LINE_AA)

            if key_response_pitch[frame_no] > 0:
                label2 = "UP + "
                cv2.putText(frame, label2, (500, 100), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 255), 4, cv2.LINE_AA)
            elif key_response_pitch[frame_no] < 0:
                label2 = "DOWN + "
                cv2.putText(frame, label2, (500, 550), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 255), 4, cv2.LINE_AA)
            else:
                label2 = ""

            if key_response_roll[frame_no] > 0:
                label3 = "CLOCKWISE +"
                cv2.putText(frame, label3, (800, 700), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 255), 2, cv2.LINE_AA)
            elif key_response_roll[frame_no] < 0:
                label3 = "C. CLOCKWISE +"
                cv2.putText(frame, label3, (50, 700), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 255), 2, cv2.LINE_AA)
            else:
                label3 = ""
            if speaking[frame_no] == 1:
                label4 = "SPEAKING"
                cv2.putText(frame, label4, (500, 700), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 3, cv2.LINE_AA)

            frame_no += 1
            out.write(frame)
            cv2.imshow("demo", frame)
            if cv2.waitKey(1) == ord("q"):
                break
            #cv2.destroyAllWindows()


def main():
        # Extract the video frames
        #videoDir = '/Users/muhittingokmen/Dropbox/CHOP-MEF-codes/Dense-Head-Pose-Estimation/video_dir'
        video = '/Users/muhittingokmen/Dropbox/CHOP-MEF-data_in/monodic/videos'
        #get the list of files in the video directory with the .mp4 extension

        avk = AugmentVideo()
        RootDir = '/Users/muhittingokmen/Dropbox/CHOP-MEF-data_in/monodic'
        videoFolder = f"{RootDir}/videos/"
        keypoint_folder = f"{RootDir}/keypoints_ext/"
        print("KeypointFolder: ", keypoint_folder)
        OutputFolder = f"{RootDir}/augmented_videos/"
        SpeakerFolder = f"{RootDir}/speaking_labels/"
        #if diractory OutputFolder does not exist, create


        keypoints_yaw_folder = f"{keypoint_folder}yaw/"
        keypoints_pitch_folder = f"{keypoint_folder}pitch/"
        keypoints_roll_folder = f"{keypoint_folder}roll/"

        videoFiles = sorted(os.listdir(videoFolder))
        #videoFiles = videoFiles[0:3]
        print("videoFiles: ", videoFiles)
        #sys.exit()
        for videoFile in sorted(videoFiles):
            if not videoFile.endswith(".mp4"):
                continue
            video_filename = f"{videoFolder}{videoFile}"
            print("video_filename: ", video_filename)
            videofile_base = os.path.splitext(videoFile)[0]

            filename = f"{videofile_base}_yaw_kines.csv"
            keypoints_yaw = f"{keypoints_yaw_folder}{filename}"
            print("KeypointFolder: ", keypoints_yaw)

            filename = f"{videofile_base}_pitch_kines.csv"
            keypoints_pitch = f"{keypoints_pitch_folder}{filename}"
            print("KeypointFolder: ", keypoints_pitch)

            filename = f"{videofile_base}_roll_kines.csv"
            keypoints_roll = f"{keypoints_roll_folder}{filename}"
            print("KeypointFolder: ", keypoints_roll)


            speaker_filename = f"{SpeakerFolder}{videofile_base}_speaking_labels.csv"
            print("speaker_filename: ", speaker_filename)

            output_filename = f"{OutputFolder}{videofile_base}_augmented.mp4"
            avk.augment_video(video_filename,  keypoints_yaw, keypoints_pitch, keypoints_roll, speaker_filename, output_filename)


if __name__ == "__main__":
    main()