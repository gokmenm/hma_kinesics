# head_motion_analysis
This repository contains the Python codes of Head Motion Analysis project, in which a framework based on kinesics are developed to analize the head motions during a dyadic communication. This framework is used to classify the CASS videos of ASD and NT participants recorded at CHOP.   
