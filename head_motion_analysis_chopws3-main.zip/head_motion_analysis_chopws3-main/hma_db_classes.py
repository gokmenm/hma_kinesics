
import sqlite3

class db_classes():
    def __int__(self, opts, **kwargs):
        self.opts = opts
        self.kwargs = kwargs

    def save_letters_to_db(self, all_letters, angles_file_name):
        if not os.path.exists(self.kwargs['databaseFolder']):
            os.makedirs(self.kwargs['databaseFolder'])
        current_filename = self
        # Connect to the SQLite database (it will be created if not exists)
        db_path = self.kwargs['databaseFolder'] + 'letter.db'
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        letter_table_name = 'letter_table'
        # Create the table if it does not exist
        create_table_query = f'''
        CREATE TABLE IF NOT EXISTS {letter_table_name} (
            file_name TEXT,
            frame_no INTEGER,
            letter TEXT,
            magnitude REAL,
            letter_yaw_component REAL,
            letter_pitch_component REAL,
            letter_roll_component REAL,
            level INTEGER,
            size REAL,
            first_frame INTEGER,
            last_frame INTEGER,
            face_no INTEGER,
            speaking INTEGER,
            conf_part INTEGER,
            fps REAL
        );
        '''
        cursor.execute(create_table_query)
        # Commit the changes to the database
        conn.commit()
        # Read the all_letter rows and insert data_in into the table
        for i in range(len(all_letters['frame_no'])):
            # Convert strings to appropriate data_in types based on the table schema
            row_data = {
                'filename': angles_file_name,
                'frame_no': int(all_letters['frame_no'][i]),
                'letter': all_letters['letter'][i],
                'magnitude': float(all_letters['magnitude'][i]),
                'letter_yaw_component': float(all_letters['letter_yaw_component'][i]),
                'letter_pitch_component': float(all_letters['letter_pitch_component'][i]),
                'letter_roll_component': float(all_letters['letter_roll_component'][i]),
                'level': all_letters['level'][i],
                'size': float(all_letters['size'][i]),
                'first_frame': int(all_letters['first_frame'][i]),
                'last_frame': int(all_letters['last_frame'][i]),
                'face_no': int(all_letters['face_no'][i]),
                'speaking': int(all_letters['speaking'][i]),
                'conf_part': int(all_letters['conf_part'][i]),
                'fps': float(all_letters['fps'][i])
            }
            # Insert data_in into the table
            insert_query = f'''
            INSERT INTO {letter_table_name} VALUES (
                :filename, :frame_no, :letter, :magnitude, :letter_yaw_component,
                :letter_pitch_component, :letter_roll_component, :level, :size,
                :first_frame, :last_frame, :face_no, :speaking, :conf_part, :fps
            );
            '''
            cursor.execute(insert_query, row_data)
        # Commit the changes to the database
        conn.commit()
        # Close the database connection
        conn.close()

    def save_hist_to_db(self, opts, histogram, filename):
        # Connect to the SQLite database (it will be created if not exists)
        db_path = self.kwargs['databaseFolder'] + 'histogram.db'
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        table_name = histogram_table'
        # Create the table if it does not exist
        create_table_query = f'''
                CREATE TABLE IF NOT EXISTS {table_name} (
                    file_name TEXT,
                    part_length INTEGER,
                    fps REAL, 
                    histogram_segment_size INTEGER, 
                    selected_levels TEXT, 
                    letter_dictionary  TEXT, 
                    hist_value TEXT, 
                    histogram_type TEXT, 
                    kineme_type TEXT, 
                    video_length INTEGER,
                    levels, 
                    histogram, 
                    segment_id, 
                    segment_size
                );
                '''
        cursor.execute(create_table_query)
        # Commit the changes to the database
        conn.commit()
        # Read the all_letter rows and insert data_in into the table
        for i in range(len(all_letters['frame_no'])):
            # Convert strings to appropriate data_in types based on the table schema
            row_data = {
                'file_name': angles_file_name,
                'part_length': int(all_letters[''][i])
                'fps':
                'histogram_segment_size':
                'selected_levels':
                'letter_dictionary':
                'hist_value':
                'histogram_type':
                'kineme_type':
                'video_length':
            }
            # Insert data_in into the table
            insert_query = f'''
                    INSERT INTO {letter_table_name} VALUES (
                        :filename, :frame_no, :letter, :magnitude, :letter_yaw_component,
                        :letter_pitch_component, :letter_roll_component, :level, :size,
                        :first_frame, :last_frame, :face_no, :speaking, :conf_part, :fps
                    );
                    '''
            cursor.execute(insert_query, row_data)
        # Commit the changes to the database
        conn.commit()
        # Close the database connection
        conn.close()


