#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 21 09:16:34 2024

@author: sariyanide
adopted to kineme by Muhittin Gokmen
"""
import os
import json
import itertools
from datetime import datetime



def save_recipe(tdir, idx, feature_type, subject_type, opts, fit_sample = None):
    feature = {'feature_type': feature_type, 
               'subject_type': subject_type,
               'feature_opts': opts}
    
    if fit_sample is not None:
        feature['fit_sample'] = fit_sample
        
    recipe = {'features': [feature]}
    os.makedirs(tdir, exist_ok=True)

    tpath = os.path.join(tdir, f'{feature_type}{idx:04d}.json')
    print(f'\r {tpath}', end='')
    
    with open(tpath, 'w') as fp:
        json.dump(recipe, fp)
    

    

def generate_kineme_recipes(feature_type, fit_sample): # "SPoseKinemeHist"
    tdir = f"/home/gokmenm/featurebox/recipes/{datetime.today().strftime('%Y%m%d')}"
    os.makedirs(tdir, exist_ok=True)

    subject_types = ['participant', 'confederate']
    input_extns = 'poses_smooth'
    #feature_ix0 = [6, 9, 10]
    commonFPS = 30
    fit_sample = None
    #hma values
    part_length = 1800           # 1800 frames. better to fix it to 1800
    sigma = 1.6  # default=1.6, gaussion pyramid's first level's sigma. 1.0, and 3.2  could be tried
    num_intervals = 3  # default=3, number of levels in one octave in the gaussion pyramid, fixed to 3
    assumed_blur = 0.5  # default=0.5, sigam of initial smoothing of filter. can be decreased to 0.1.
    signal_border_width = 5  # default=5, the width of the border of the signal
    contrast_threshold=0.01  # default=0.01, the contrast threshold for detecting kines. smaller value gives more kines
    min_size=32.0  # default=32.0, the minimum size of SIFT pyramid. larger value decreses number of octaves and levels
    face_number=1  # person_id for the video file
    speaking_id=1  # 1 if person is speaking, 0 if listening (# it should be changed by frame by framr values in angles file)
    conf_part_id=1  # 1 for confederate, 0 for participant
    fps=25,  # default=25, frames per second
    min_silence=5  # default=5, minimum silence duration in seconds.  a larger value eliminates gaps between letters
    silent_block_size=10  # default=10, the size of the silent block in frames. a larger value descreases the number of silent blocks denoted as '_'

    selected_levels_147101316 = [1, 4, 7, 10, 13, 16]
    selected_levels_14710 = [1, 4, 7, 10]
    selected_levels_147 = [1, 4, 7]
    selected_levels_4710 = [4, 7, 10]
    letter_dictionary = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o','p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '_']

    # feature lists that combinations will be created
    histogram_segment_numbers = [7, 10]
    histogram_segment_sizes = [-1, 20]
    histogram_segment_types = ['segment_size', 'segment_number']
    selected_levelss = [selected_levels_147101316, selected_levels_14710, selected_levels_147, selected_levels_4710]
    histogram_types = ['kineme_levels','kineme_combined', 'kineme_levels_and_combined']
    kineme_types = ['single_letters','one_nod', 'two_nod', 'three_nod', 'one_sweep', 'two_sweep', 'three_sweep','singleton']
    speaking_listenings = ['speaking', 'listening' ,  'nonseparated' ,  'separated_and_combined']
    hist_values = ["count","magnitude"]

    idx = 0
    #for post_processing in ['mean', 'mean_std', 'std']:
    for (subject_type, histogram_segment_number,histogram_segment_size,histogram_segment_type, selected_levels, histogram_type, kineme_type, speaking_listening, hist_value) in \
        itertools.product(subject_types, histogram_segment_numbers, histogram_segment_sizes, histogram_segment_types, selected_levelss, histogram_types, kineme_types, speaking_listenings, hist_values):
        idx += 1
        opts = { "part_length": part_length,           # 1800 frames. better to fix it to 1800
                 "sigma": sigma,                  # default=1.6, gaussion pyramid's first level's sigma. 1.0 could be tried
                 "num_intervals": num_intervals,            # default=3, number of levels in one octave in the gaussion pyramid, fixed to 3
                 "assumed_blur": assumed_blur,           # default=0.5, sigam of initial smoothing of filter. can be decreased to 0.1.
                 "signal_border_width": signal_border_width,      # default=5, the width of the border of the signal
                 "contrast_threshold": contrast_threshold,    # default=0.01, the contrast threshold for detecting kines. smaller value gives more kines
                 "min_size": min_size,              # default=32.0, the minimum size of SIFT pyramid. larger value decreses number of octaves and levels
                 "fps": commonFPS,                     # default=25, frames per second
                 "min_silence": min_silence,              # default=5, minimum silence duration in seconds.  a larger value eliminates gaps between letters
                 "silent_block_size": silent_block_size,       # default=10, the size of the silent block in frames. a larger value descreases the number of silent blocks denoted as '_'
                 "histogram_segment_number": histogram_segment_number,                    # [20, 40, -1] default 20, multiplied by fps,  -1 for all frames
                 "histogram_segment_size": histogram_segment_size,              # [10, 20, 30] default 20, multiplied by fps,  -1 for all frames
                 "histogram_segment_type": histogram_segment_type,              # ['select_size', 'select_number'] default 'select_size'
                 "selected_levels": selected_levels,
                 "letter_dictionary": letter_dictionary,
                 "hist_value": hist_value,  #  ["count","magnitude"]
                 "histogram_type": histogram_type, # 'kineme_levels_and_combined',  # ['letter_levels','letter_combined', 'letter_levels_and_combined',
                 "kineme_type": kineme_type,       #'single_letters',    # ['single_letters','one_nod', 'two_nod', 'three_nod', 'one_sweep', 'two_sweep', 'three_sweep','singleton']
                 "speaking_listening": speaking_listening,       #'separated_and_combined',  # ['speaking', 'listening' ,  'nonseparated' ,  'separated_and_combined']
                 "subject_type" : subject_type,
                 "commonFPS": commonFPS,
                 "input_extn": input_extns,
                 "feature_ix0": 6,
                 "feature_ixf": 9,
        }
        save_recipe(tdir, idx, feature_type, subject_type, opts, fit_sample)
                
    print()



if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--fit_sample', type=str, default=None, required=True)
    args = parser.parse_args()

    generate_kineme_recipes("SPoseKinemeHist", args.fit_sample)

